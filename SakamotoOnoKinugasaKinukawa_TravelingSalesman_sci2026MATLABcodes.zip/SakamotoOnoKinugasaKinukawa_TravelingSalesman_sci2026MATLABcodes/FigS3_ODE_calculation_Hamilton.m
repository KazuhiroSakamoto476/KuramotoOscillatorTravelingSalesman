% ODE_calculation_50bodyTravellingSalesman

% �n�~���g���H�̗�

osci_no = 20;
%osci_no = 21; % �h�[�s���O����

omega = ones(osci_no,1)*0.00001; % �ʑ����x�̎w��

% �ŒZ�H��1�ɂ��Ă����B����ȊO�̌o�H��sp, ���݂��Ȃ��o�H��lp�Ŏw�肷�邱�ƂŁA�Ȃ�Ƃ��o��B�M�d ,sp, lp�������Ȃ�
sp = 1.1;
lp = 1.1;
% ���R�ȍl���̗�B���݂���o�H��1, ���݂��Ȃ��o�H�͏\���ɑ傫���l�Ƃ���1000
%sp = 1;
%lp = 1000;
%dp = 12000; % ��̗�ɑ΂���h�[�s���O
rates = 0;
ratel = 0;
% �h�[�s���O�Ȃ�
%{
w = [0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel; 
     0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,sp+rand*rates;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
 %}
%%{
w = [0,1,lp+rand*ratel,lp+rand*ratel,1,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel; 
     0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,1,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,1,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel,1;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,lp+rand*ratel,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
 %}
% �h�[�s���O����
%{
w = [0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp; 
     0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,sp+rand*rates,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,lp+rand*ratel,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp+rand*rates,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,dp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
 %} 
 w = w + w.';

        
% ����ۑ��֌W
% ���́Aw�̒�`��艺�ɂ��Ă����Ȃ��Ɓu�x��: ���̃t�@�C���ɂ̓r�f�I�t���[�����������܂�Ă��܂���B�t�@�C���������ɂȂ�\��������܂��B�v�Ƃ����̂��o��B
v = VideoWriter('oscillators.avi');% ����I
open(v); % ����I

t = linspace(0,50,5000);

% �`��֌W
    
% �~�i�ʑ���ԁj�̕`��
%%{
figure (1);
plot(sin(t),cos(t),'black',"LineWidth",3.0);
axis manual
daspect([1 1 1]) % �c������Œ肷��
axis('off');  % ���̐�������
set(gca, 'XTickLabel', {}, 'YTickLabel', {}); % ���x��������
set(gcf, 'Color', 'white');  % Figure�̔w�i�F�𔒂ɂ���
txt = '0.0';
tmp_txt = text(-0.35,0,txt,'FontSize',20);
%%}
   
c = zeros(osci_no,1);
for i=1:size(c,1) % �ʑ��̏����l�̐ݒ�
    c(i) = rand*2*pi;
end

X = cos(c);
Y = sin(c);
    
% �`��֌W
%%{
hold on    
p = [];
for i=1:osci_no
    if i==1
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 0 0],'MarkerFaceColor',[0.5 0 0],'MarkerSize',70)];
    elseif i==2
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 0 0.5],'MarkerFaceColor',[0.5 0 0.5],'MarkerSize',70)];    
    elseif i==3
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0 0 0.5],'MarkerFaceColor',[0 0 0.5],'MarkerSize',70)];    
    elseif i==4
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0 0.5 0],'MarkerFaceColor',[0 0.5 0],'MarkerSize',70)];    
    elseif i==5
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 0.5 0],'MarkerFaceColor',[0.5 0.5 0],'MarkerSize',70)];    
    elseif i==6
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',70)];    
    elseif i==7
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 0 0.5],'MarkerFaceColor',[1 0 0.5],'MarkerSize',70)];    
    elseif i==8
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 0 1],'MarkerFaceColor',[1 0 1],'MarkerSize',70)];
    elseif i==9
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 0 1],'MarkerFaceColor',[0.5 0 1],'MarkerSize',70)];
    elseif i==10
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0 0 1],'MarkerFaceColor',[0 0 1],'MarkerSize',70)];
    elseif i==11
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0 1 1],'MarkerFaceColor',[0 1 1],'MarkerSize',70)];
    elseif i==12
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0 1 0],'MarkerFaceColor',[0 1 0],'MarkerSize',70)];
    elseif i==13
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 1 0],'MarkerFaceColor',[0.5 1 0],'MarkerSize',70)];
    elseif i==14
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 1 0],'MarkerFaceColor',[1 1 0],'MarkerSize',70)];
    elseif i==15
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 0.5 0],'MarkerFaceColor',[1 0.5 0],'MarkerSize',70)];
    elseif i==16
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 0.5 0.5],'MarkerFaceColor',[1 0.5 0.5],'MarkerSize',70)];
    elseif i==17
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 0.5 1],'MarkerFaceColor',[0.5 0.5 1],'MarkerSize',70)];
    elseif i==18
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 1 1],'MarkerFaceColor',[0.5 1 1],'MarkerSize',70)];
    elseif i==19
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0.5 1 0.5],'MarkerFaceColor',[0.5 1 0.5],'MarkerSize',70)];
    elseif i==20
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 1 0.5],'MarkerFaceColor',[1 1 0.5],'MarkerSize',70)];
    elseif i==21 % �h�[�s���O��
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0],'MarkerSize',70)];
    end
end    
hold off
%}

% �����������������Ƃ���
% https://jp.mathworks.com/help/matlab/math/summary-of-ode-options.html
%odeset % �ݒ�̒��g��\�������邱�Ƃ��ł���B
[t,y] = ode23s(@(t,y) kuramoto_oscillators_Hamilton(t,y,w,omega),[0 2000000],c); % ���ԋ�ԁA�����l ���Ԃ�50oscillators�ɍ��킹�Ă���

% �\��
for i = 1:length(t)    
    for j=1:osci_no
        X(j,i) = cos(y(i,j));
        Y(j,i) = sin(y(i,j));
        % �`��֌W
        %%{
        p(j).XData = X(j,i);
        p(j).YData = Y(j,i);
        %}
    end
        
    % �`��֌W
    %%{
    pause(0.1) % �\���X�s�[�h�𒲐߁@0.1����0.1�b�Ɉ��`��
    delete(tmp_txt);
    tmp_txt = text(-0.35,0,num2str(t(i)),'FontSize',20);
    drawnow
    %}
    % ����ۑ��֌W
    frame = getframe(gcf); % ����I
    writeVideo(v,frame); % ����I
        
    %drawnow limitrate % �Ƃ��Ƃƌv�Z�������ꍇ�͏�Q�s���R�����g�A�E�g���Ă�����g���B
end
    
% ����ۑ��֌W
close(v); % ����I

% �U���q�P����̍��B�U���q1->2�̕����ő�����B
angles = rad2deg(atan2(Y(:,size(X,2)),X(:,size(X,2))));
tmp_angle_diff = angles(:) - angles(1);
if (abs(tmp_angle_diff(2)) > 180 && sign(tmp_angle_diff(2))>=0) || (abs(tmp_angle_diff(2)) <= 180 && sign(tmp_angle_diff(2))<0)
    tmp_angle_diff = -tmp_angle_diff; % 1~2�̈ʑ�����0~pi�͈̔͂Ɏ��߂�悤�ɕ����𔽓]
end
for i=2:osci_no
    if tmp_angle_diff(i)<0
        tmp_angle_diff(i) = tmp_angle_diff(i) + 360; % �Ƃɂ����p�x�͐��ŕ\�� 
    end
end
% �ʑ��֌W�̊i�[
phase_order = [];
for l = 1:osci_no
    phase_order = [phase_order,l];
end
[tmp_angle_diff,I] = sort(tmp_angle_diff);
phase_order = phase_order(I);

% �`��
%%{
figure (2);
for i = 1:osci_no-1
    if i == 1
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 0 0.5],"LineWidth",15.0); %�_���̊G�́A����4.0
    elseif i == 2
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0 0 0.5],"LineWidth",15.0);
    elseif i == 3
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0 0.5 0],"LineWidth",15.0);
    elseif i == 4
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 0.5 0],"LineWidth",15.0);
    elseif i == 5
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 0 0],"LineWidth",15.0);
    elseif i == 6
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 0 0.5],"LineWidth",15.0);
    elseif i == 7
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 0 1],"LineWidth",15.0);
    elseif i == 8
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 0 1],"LineWidth",15.0);
    elseif i == 9
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0 0 1],"LineWidth",15.0);
    elseif i == 10
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0 1 1],"LineWidth",15.0);
    elseif i == 11
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0 1 0],"LineWidth",15.0);
    elseif i == 12
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 1 0],"LineWidth",15.0);
    elseif i == 13
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 1 0],"LineWidth",15.0);
    elseif i == 14
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 0.5 0],"LineWidth",15.0);
    elseif i == 15
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 0.5 0.5],"LineWidth",15.0);
    elseif i == 16
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 0.5 1],"LineWidth",15.0);
    elseif i == 17
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 1 1],"LineWidth",15.0);
    elseif i == 18
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0.5 1 0.5],"LineWidth",15.0);
    elseif i == 19
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 1 0.5],"LineWidth",15.0);
    elseif i == 20 % �h�[�s���O
        plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[0 0 0],"LineWidth",15.0);    end
    if i == 1
        hold on;
    elseif i == osci_no-1
        hold off;
    end
        
end          

 