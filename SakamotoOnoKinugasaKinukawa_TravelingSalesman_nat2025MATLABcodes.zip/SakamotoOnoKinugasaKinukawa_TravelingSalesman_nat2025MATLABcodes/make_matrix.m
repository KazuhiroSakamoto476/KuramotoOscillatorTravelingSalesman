if osci_no == 3
        w = [     0, wij(1), wij(2);
             wij(1),      0, wij(3);
             wij(2), wij(3),      0];

elseif osci_no == 4
        w = [     0, wij(1), wij(2), wij(3);
             wij(1),      0, wij(4), wij(5);
             wij(2), wij(4),      0, wij(6);
             wij(3), wij(5), wij(6),      0];
elseif osci_no == 5
        w = [     0, wij(1), wij(2), wij(3), wij(4);
             wij(1),      0, wij(5), wij(6), wij(7);
             wij(2), wij(5),      0, wij(8), wij(9);
             wij(3), wij(6), wij(8),      0,wij(10);
             wij(4), wij(7), wij(9),wij(10),      0];
elseif osci_no == 6
        w = [     0, wij(1), wij(2), wij(3), wij(4), wij(5);
             wij(1),      0, wij(6), wij(7), wij(8), wij(9);
             wij(2), wij(6),      0,wij(10),wij(11),wij(12);
             wij(3), wij(7),wij(10),      0,wij(13),wij(14);
             wij(4), wij(8),wij(11),wij(13),      0,wij(15);
             wij(5), wij(9),wij(12),wij(14),wij(15),      0];
elseif osci_no == 7
        w = [     0, wij(1), wij(2), wij(3), wij(4), wij(5), wij(6);
             wij(1),      0, wij(7), wij(8), wij(9),wij(10),wij(11);
             wij(2), wij(7),      0,wij(12),wij(13),wij(14),wij(15);
             wij(3), wij(8),wij(12),      0,wij(16),wij(17),wij(18);
             wij(4), wij(9),wij(13),wij(16),      0,wij(19),wij(20);
             wij(5),wij(10),wij(14),wij(17),wij(19),      0,wij(21);
             wij(6),wij(11),wij(15),wij(18),wij(20),wij(21),      0];
elseif osci_no == 8
        w = [     0, wij(1), wij(2), wij(3), wij(4), wij(5), wij(6), wij(7);
             wij(1),      0, wij(8), wij(9),wij(10),wij(11),wij(12),wij(13);
             wij(2), wij(8),      0,wij(14),wij(15),wij(16),wij(17),wij(18);
             wij(3), wij(9),wij(14),      0,wij(19),wij(20),wij(21),wij(22);
             wij(4),wij(10),wij(15),wij(19),      0,wij(23),wij(24),wij(25);
             wij(5),wij(11),wij(16),wij(20),wij(23),      0,wij(26),wij(27);
             wij(6),wij(12),wij(17),wij(21),wij(24),wij(26),      0,wij(28);
             wij(7),wij(13),wij(18),wij(22),wij(25),wij(27),wij(28),      0];
elseif osci_no == 9
        w = [     0, wij(1), wij(2), wij(3), wij(4), wij(5), wij(6), wij(7), wij(8);
             wij(1),      0, wij(9),wij(10),wij(11),wij(12),wij(13),wij(14),wij(15);
             wij(2), wij(9),      0,wij(16),wij(17),wij(18),wij(19),wij(20),wij(21);
             wij(3),wij(10),wij(16),      0,wij(22),wij(23),wij(24),wij(25),wij(26);
             wij(4),wij(11),wij(17),wij(22),      0,wij(27),wij(28),wij(29),wij(30);
             wij(5),wij(12),wij(18),wij(23),wij(27),      0,wij(31),wij(32),wij(33);
             wij(6),wij(13),wij(19),wij(24),wij(28),wij(31),      0,wij(34),wij(35);
             wij(7),wij(14),wij(20),wij(25),wij(29),wij(32),wij(34),      0,wij(36);
             wij(8),wij(15),wij(21),wij(26),wij(30),wij(33),wij(35),wij(36),      0];
elseif osci_no == 10
        w = [     0, wij(1), wij(2), wij(3), wij(4), wij(5), wij(6), wij(7), wij(8), wij(9);
             wij(1),      0,wij(10),wij(11),wij(12),wij(13),wij(14),wij(15),wij(16),wij(17);
             wij(2),wij(10),      0,wij(18),wij(19),wij(20),wij(21),wij(22),wij(23),wij(24);
             wij(3),wij(11),wij(18),      0,wij(25),wij(26),wij(27),wij(28),wij(29),wij(30);
             wij(4),wij(12),wij(19),wij(25),      0,wij(31),wij(32),wij(33),wij(34),wij(35);
             wij(5),wij(13),wij(20),wij(26),wij(31),      0,wij(36),wij(37),wij(38),wij(39);
             wij(6),wij(14),wij(21),wij(27),wij(32),wij(36),      0,wij(40),wij(41),wij(42);
             wij(7),wij(15),wij(22),wij(28),wij(33),wij(37),wij(40),      0,wij(43),wij(44);
             wij(8),wij(16),wij(23),wij(29),wij(34),wij(38),wij(41),wij(43),      0,wij(45);
             wij(9),wij(17),wij(24),wij(30),wij(35),wij(39),wij(42),wij(44),wij(45),      0];
end
