% three_oscillators

%d = [0, 0.376747404, 0.459076494; 0.376747404, 0, 0.441011742; 0.459076494, 0.441011742, 0];
%d = [0, 1, 0.9; 1, 0, 0.4; 0.9, 0.4, 0]; % 2�N���X�^�[�̗�B1vs.(2,3)�܂�A1��2��pi, 2��3��0, 1��3��pi
%d = [0, 0.43, 0.67; 0.43, 0, 0.34; 0.67, 0.34, 0]; % d21+d13>d32, d21+d32>d13, d32+d13>d21
tmp_d = 0.49;
d = [0, 1, tmp_d; 1, 0, 1; tmp_d, 1, 0];
d_ang = d/max(max(d));
d_ang = asin(d_ang);
%d_ang = asin(d);

%{
[theta1, theta2] = meshgrid(-1*pi:0.001*pi:1*pi,-1*pi:0.001*pi:1*pi);
theta3 = 2*pi() - theta1 - theta2;
diff12 = theta1 - theta2;
diff13 = theta1 - theta3;
diff23 = theta2 - theta3;
%}
[diff12, diff23] = meshgrid(-pi*1:0.005*pi:pi*1,-pi*1:0.005*pi:pi*1);
diff13 = 2*pi() - diff12 - diff23;
%[diff12, diff13] = meshgrid(-pi*1.5:0.001*pi:pi*1.5,-pi*1.5:0.001*pi:pi*1.5);
%diff23 = diff13 - diff12;
omega = 0; %0.001;

%%%%%%%
%potential = -omega*(theta1 + theta2 + theta3) + d(1,2)*cos(diff12) + d(1,3)*cos(diff13) + d(2,3)*cos(diff23);
potential = d(1,2)*cos(diff12) + d(1,3)*cos(diff13) + d(2,3)*cos(diff23);

figure(1)
s1 = surf(diff12, diff23, potential);
%s1 = surf(diff12, diff13, potential);
s1.EdgeColor = 'none';

potential_min = min(min(potential));
[tmp1_1, tmp1_2] = find(potential == potential_min);
diff12_min = diff12(tmp1_1, tmp1_2);
%diff13_min = diff13(tmp1_1, tmp1_2);
diff23_min = diff23(tmp1_1, tmp1_2);
%diff23_min = abs(wrapToPi(diff13_min)) - abs(wrapToPi(diff12_min));
diff13_min = 2*pi - abs(wrapToPi(diff12_min)) - abs(wrapToPi(diff23_min));
diff_min_rad = [diff12_min,diff13_min,diff23_min];
diff_min_rad = wrapToPi(diff_min_rad);
diff_min_angle = abs(diff_min_rad*180/pi);

%%%%%%%%
%{
%potential2 = -omega*(theta1 + theta2 + theta3) + 0.5*(sin(d_ang(1,2) + diff12) + sin(d_ang(1,2) - diff12) + sin(d_ang(1,3) + diff13) + sin(d_ang(1,3) - diff13) + sin(d_ang(2,3) + diff23) + sin(d_ang(2,3) - diff23));
potential2 = 0.5*(sin(d_ang(1,2) + diff12) + sin(d_ang(1,2) - diff12) + sin(d_ang(1,3) + diff13) + sin(d_ang(1,3) - diff13) + sin(d_ang(2,3) + diff23) + sin(d_ang(2,3) - diff23));

figure(2)
s2 = surf(diff12, diff23, potential2);
s2.EdgeColor = 'none';

potential2_min = min(min(potential2));
[tmp2_1, tmp2_2] = find(potential2 == potential2_min);
diff12_min2 = diff12(tmp2_1, tmp2_2);
diff13_min2 = diff13(tmp2_1, tmp2_2);
diff23_min2 = 2*pi - abs(wrapToPi(diff12_min2)) - abs(wrapToPi(diff13_min2));
diff_min_rad2 = [diff12_min2,diff13_min2,diff23_min2];
diff_min_rad2 = wrapToPi(diff_min_rad2);
diff_min_angle2 = abs(diff_min_rad2*180/pi);
%}
