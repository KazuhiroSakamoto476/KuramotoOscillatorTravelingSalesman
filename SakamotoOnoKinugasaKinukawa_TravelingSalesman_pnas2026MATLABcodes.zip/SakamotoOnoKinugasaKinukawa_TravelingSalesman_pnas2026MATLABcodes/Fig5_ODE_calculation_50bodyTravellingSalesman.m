% ODE_calculation_50bodyTravellingSalesman

% ������������̌v�Z�ƕ\���F50�U���q�̃f����

osci_no =50;%9; % �U���q�̐� 9�Ōv�Z����邱�Ƃ��m�F

omega = ones(osci_no,1)*0.00001; % �ʑ����x�̎w��
    
% �ŒZ�o�H���w��B1->49�̏��ɍŒZ�o�H�ɂȂ�悤�ɁB
% �܂��̓V�����g���J���ɂ���āA�Ђ�������悤�Ȃ�A��������������B
sp = 1; % short path
lp = 1.68; % long path
dp = 1.68; %�h�[�s���O�U���q�̋��� sp 0.5, lp 1�̏ꍇ�A2�N���X�^��臒l��48.9��49�̊�
rate_l = 0.01;%1;%0.01; % �ŒZ�o�H�ȊO�̌o�H(lp)�ɂǂ̂��炢�����_���������邩
rate_d = 0.01;%1;%0.01; % �h�[�s���O�U���q�̋����ɂǂ̂��炢�����_���������邩


w = [0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,lp+rand*rate_l,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp,dp+rand*rate_d;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,sp;
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
 w = w + w.'; % �Ίp���͓����ɂ��Ȃ���΂Ȃ�Ȃ��B

        
% ����ۑ��֌W
% ���́Aw�̒�`��艺�ɂ��Ă����Ȃ��Ɓu�x��: ���̃t�@�C���ɂ̓r�f�I�t���[�����������܂�Ă��܂���B�t�@�C���������ɂȂ�\��������܂��B�v�Ƃ����̂��o��B
v = VideoWriter('oscillators.avi');% ����I
open(v); % ����I

t = linspace(0,50,50000);

% �`��֌W
    
% �~�i�ʑ���ԁj�̕`��
%%{
figure (1);
plot(sin(t),cos(t),'black',"LineWidth",3.0);
axis manual
daspect([1 1 1]) % �c������Œ肷��
axis('off');  % ���̐�������
set(gca, 'XTickLabel', {}, 'YTickLabel', {}); % ���x��������
set(gcf, 'Color', 'white');  % Figure�̔w�i�F�𔒂ɂ���
%set(gca, 'Color', 'none');  % axes�̔w�i�F�𓧖��ɂ���
txt = '0.0';
tmp_txt = text(-0.35,0,txt,'FontSize',20);
%%}
   
c = zeros(osci_no,1);
for i=1:size(c,1) % �ʑ��̏����l�̐ݒ�
    c(i) = rand*2*pi; %pi*2/5+rand*0.01;
end

X = cos(c);
Y = sin(c);
    
% �`��֌W
%%{
hold on    
p = [];
for i=1:osci_no
    if i == 51
        p = [p;plot(X(1,1),Y(1,1),"o",'MarkerEdgeColor',[0.25,0,0],'MarkerFaceColor',[0.25,0,0],'MarkerSize',50)];
    else
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[1 0.02*(i-1) 0.02*(i-1)],'MarkerFaceColor',[1 0.02*(i-1) 0.02*(i-1)],'MarkerSize',50)];
        %p = [p;plot(X(1,1),Y(1,1),'o','MarkerEdgeColor',[0,0,0],'MarkerFaceColor',[1 0.02*(i-1) 0.02*(i-1)],'MarkerSize',40)];
    end
    %{
    if i==1
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','white','MarkerSize',20)];
    elseif i==2
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','red','MarkerSize',20)];    
    elseif i==3
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','green','MarkerSize',20)];    
    elseif i==4
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','blue','MarkerSize',20)];    
    elseif i==5
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','magenta','MarkerSize',20)];    
    elseif i==6
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','cyan','MarkerSize',20)];    
    elseif i==7
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','yellow','MarkerSize',20)];    
    elseif i==8
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor','black','MarkerSize',20)];
    elseif i==9
        p = [p;plot(X(1,1),Y(1,1),'o','MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',20)];
    end
    %}
end    
hold off
%}

% �����������������Ƃ���@Sfiff�\���o�[�S���
%[t,y] = ode23s(@(t,y) kuramoto_oscillators_50bodyTravellingSalesman(t,y,w,omega),[0 2000000000],c); % ���ԋ�ԁA�����l
%[t,y] = ode23s(@(t,y) kuramoto_oscillators_50bodyTravellingSalesman(t,y,w,omega),[0 100000000],c); % ���ԋ�ԁA�����l
[t,y] = ode23s(@(t,y) kuramoto_oscillators_50bodyTravellingSalesman(t,y,w,omega),[0 10000000],c); % ���ԋ�ԁA�����l
%[t,y] = ode23s(@(t,y) kuramoto_oscillators_50bodyTravellingSalesman(t,y,w,omega),[0 50000],c); % ���ԋ�ԁA�����l

% �\��
for i = 1:length(t)    
    for j=1:osci_no
        X(j,i) = cos(y(i,j));
        Y(j,i) = sin(y(i,j));
        % �`��֌W
        %%{
        p(j).XData = X(j,i);
        p(j).YData = Y(j,i);
        %}
    end
        
    % �`��֌W
    %%{
    pause(0.1) % �\���X�s�[�h�𒲐߁@0.1����0.1�b�Ɉ��`��
    delete(tmp_txt);
    tmp_txt = text(-0.35,0,num2str(t(i)),'FontSize',20);
    drawnow
    %}
    % ����ۑ��֌W
    frame = getframe(gcf); % ����I
    writeVideo(v,frame); % ����I
        
    %drawnow limitrate % �Ƃ��Ƃƌv�Z�������ꍇ�͏�Q�s���R�����g�A�E�g���Ă�����g���B
end
    
% ����ۑ��֌W
close(v); % ����I

% �`��
%%{
figure (2);
for i = 1:osci_no-1
    plot(t,mod(y(:,i+1)-y(:,1),2*pi),'Color',[1 0.015*i 0.015*i],"LineWidth",4.0);
    if i == 1
        hold on;
    elseif i == osci_no-1
        hold off;
    end
end          

 