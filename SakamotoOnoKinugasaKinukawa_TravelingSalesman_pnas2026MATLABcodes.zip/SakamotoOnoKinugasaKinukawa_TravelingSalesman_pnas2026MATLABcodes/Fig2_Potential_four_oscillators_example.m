% four_oscillators

% Fig.1�̗�
%tmp_d = 0; % Fig.1b�̏ꍇ�B���̂Ƃ�diff12 = 69.3, diff23 = 69.3, diff34 = 110.7, diff41 = 110.7�Ɏ���
tmp_d = 1; % Fig.1g�̏ꍇ�B���̂Ƃ�diff12 = 0, diff23 = 180, diff34 = 0, diff41 = 180�Ɏ���
d = [      0,       1, sqrt(2),       2;
           1,       0, 1+tmp_d, sqrt(3);
     sqrt(2), 1+tmp_d,       0, 2-tmp_d;
           2, sqrt(3), 2-tmp_d,       0];
d_ang = d/max(max(d));
d_ang = asin(d_ang);

margin_rate = 1;
[diff12, diff23, diff34] = meshgrid(-pi*margin_rate:0.005*pi:pi*margin_rate,-pi*margin_rate:0.005*pi:pi*margin_rate,-pi*margin_rate:0.005*pi:pi*margin_rate);
diff41 = 2*pi() - diff12 - diff23 - diff34;

potential = d(1,2)*cos(diff12) + d(1,3)*cos(diff12+diff23) + d(1,4)*cos(diff41) + d(2,3)*cos(diff23) + d(2,4)*cos(diff23+diff34) + d(3,4)*cos(diff34);

% diff34 �̎����l�ɍł��߂��s��̔ԍ���T���B
%bottom_angle = 110.7; % tmp_d = 2�A�܂�AFig.1b�̏ꍇ
bottom_angle = 0; % tmp_d = 1�A�܂�AFig.1g�̏ꍇ
bottom_position = round(size(diff34,1) * (bottom_angle + 180*margin_rate)/(360*margin_rate));

figure(1)
s1 = surf(diff12(:,:,bottom_position), diff23(:,:,bottom_position), potential(:,:,bottom_position));
s1.EdgeColor = 'none';

% tmp_d = 2�̏ꍇ�A69.3 deg = 1.2095 rad, 110.7 deg = 1.9321 rad
% tmp_d = 1�̏ꍇ�A0 rad, pi rad

% �J�̈ʒu�̌v��
potential_min = min(min(potential(:,:,bottom_position)));

[tmp1_1, tmp1_2] = find(potential == potential_min);
diff12_min = diff12(tmp1_1, tmp1_2);
diff23_min = diff23(tmp1_1, tmp1_2);
diff_min_rad = [diff12_min,diff23_min];
diff_min_rad = wrapToPi(diff_min_rad);
diff_min_angle = abs(diff_min_rad*180/pi);
