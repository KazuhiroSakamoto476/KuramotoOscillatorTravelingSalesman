function dydt = kuramoto_oscillators_NbodyTravellingSalesman_VariousParameters(t,y,w,omega,osci_no)

w = w * (-0.0001); % -0.0001

if osci_no == 3        
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3))
            ];
elseif osci_no == 4        
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4))
            ];
elseif osci_no == 5
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1)) + w(1,5)*sin(y(5) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2)) + w(2,5)*sin(y(5) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3)) + w(3,5)*sin(y(5) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4)) + w(4,5)*sin(y(5) - y(4));
            omega(5) + w(5,1)*sin(y(1) - y(5)) + w(5,2)*sin(y(2) - y(5)) + w(5,3)*sin(y(3) - y(5)) + w(5,4)*sin(y(4) - y(5))
            ];
elseif osci_no == 6
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1)) + w(1,5)*sin(y(5) - y(1)) + w(1,6)*sin(y(6) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2)) + w(2,5)*sin(y(5) - y(2)) + w(2,6)*sin(y(6) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3)) + w(3,5)*sin(y(5) - y(3)) + w(3,6)*sin(y(6) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4)) + w(4,5)*sin(y(5) - y(4)) + w(4,6)*sin(y(6) - y(4));
            omega(5) + w(5,1)*sin(y(1) - y(5)) + w(5,2)*sin(y(2) - y(5)) + w(5,3)*sin(y(3) - y(5)) + w(5,4)*sin(y(4) - y(5)) + w(5,6)*sin(y(6) - y(5));
            omega(6) + w(6,1)*sin(y(1) - y(6)) + w(6,2)*sin(y(2) - y(6)) + w(6,3)*sin(y(3) - y(6)) + w(6,4)*sin(y(4) - y(6)) + w(6,5)*sin(y(5) - y(6))        
            ];
elseif osci_no == 7
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1)) + w(1,5)*sin(y(5) - y(1)) + w(1,6)*sin(y(6) - y(1)) + w(1,7)*sin(y(7) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2)) + w(2,5)*sin(y(5) - y(2)) + w(2,6)*sin(y(6) - y(2)) + w(2,7)*sin(y(7) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3)) + w(3,5)*sin(y(5) - y(3)) + w(3,6)*sin(y(6) - y(3)) + w(3,7)*sin(y(7) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4)) + w(4,5)*sin(y(5) - y(4)) + w(4,6)*sin(y(6) - y(4)) + w(4,7)*sin(y(7) - y(4));
            omega(5) + w(5,1)*sin(y(1) - y(5)) + w(5,2)*sin(y(2) - y(5)) + w(5,3)*sin(y(3) - y(5)) + w(5,4)*sin(y(4) - y(5)) + w(5,6)*sin(y(6) - y(5)) + w(5,7)*sin(y(7) - y(5));
            omega(6) + w(6,1)*sin(y(1) - y(6)) + w(6,2)*sin(y(2) - y(6)) + w(6,3)*sin(y(3) - y(6)) + w(6,4)*sin(y(4) - y(6)) + w(6,5)*sin(y(5) - y(6)) + w(6,7)*sin(y(7) - y(6));
            omega(7) + w(7,1)*sin(y(1) - y(7)) + w(7,2)*sin(y(2) - y(7)) + w(7,3)*sin(y(3) - y(7)) + w(7,4)*sin(y(4) - y(7)) + w(7,5)*sin(y(5) - y(7)) + w(7,6)*sin(y(6) - y(7))  
            ];
elseif osci_no == 8
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1)) + w(1,5)*sin(y(5) - y(1)) + w(1,6)*sin(y(6) - y(1)) + w(1,7)*sin(y(7) - y(1)) + w(1,8)*sin(y(8) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2)) + w(2,5)*sin(y(5) - y(2)) + w(2,6)*sin(y(6) - y(2)) + w(2,7)*sin(y(7) - y(2)) + w(2,8)*sin(y(8) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3)) + w(3,5)*sin(y(5) - y(3)) + w(3,6)*sin(y(6) - y(3)) + w(3,7)*sin(y(7) - y(3)) + w(3,8)*sin(y(8) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4)) + w(4,5)*sin(y(5) - y(4)) + w(4,6)*sin(y(6) - y(4)) + w(4,7)*sin(y(7) - y(4)) + w(4,8)*sin(y(8) - y(4));
            omega(5) + w(5,1)*sin(y(1) - y(5)) + w(5,2)*sin(y(2) - y(5)) + w(5,3)*sin(y(3) - y(5)) + w(5,4)*sin(y(4) - y(5)) + w(5,6)*sin(y(6) - y(5)) + w(5,7)*sin(y(7) - y(5)) + w(5,8)*sin(y(8) - y(5));
            omega(6) + w(6,1)*sin(y(1) - y(6)) + w(6,2)*sin(y(2) - y(6)) + w(6,3)*sin(y(3) - y(6)) + w(6,4)*sin(y(4) - y(6)) + w(6,5)*sin(y(5) - y(6)) + w(6,7)*sin(y(7) - y(6)) + w(6,8)*sin(y(8) - y(6));
            omega(7) + w(7,1)*sin(y(1) - y(7)) + w(7,2)*sin(y(2) - y(7)) + w(7,3)*sin(y(3) - y(7)) + w(7,4)*sin(y(4) - y(7)) + w(7,5)*sin(y(5) - y(7)) + w(7,6)*sin(y(6) - y(7)) + w(7,8)*sin(y(8) - y(7));
            omega(8) + w(8,1)*sin(y(1) - y(8)) + w(8,2)*sin(y(2) - y(8)) + w(8,3)*sin(y(3) - y(8)) + w(8,4)*sin(y(4) - y(8)) + w(8,5)*sin(y(5) - y(8)) + w(8,6)*sin(y(6) - y(8)) + w(8,7)*sin(y(7) - y(8))        
            ];
elseif osci_no == 9
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1)) + w(1,5)*sin(y(5) - y(1)) + w(1,6)*sin(y(6) - y(1)) + w(1,7)*sin(y(7) - y(1)) + w(1,8)*sin(y(8) - y(1)) + w(1,9)*sin(y(9) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2)) + w(2,5)*sin(y(5) - y(2)) + w(2,6)*sin(y(6) - y(2)) + w(2,7)*sin(y(7) - y(2)) + w(2,8)*sin(y(8) - y(2)) + w(2,9)*sin(y(9) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3)) + w(3,5)*sin(y(5) - y(3)) + w(3,6)*sin(y(6) - y(3)) + w(3,7)*sin(y(7) - y(3)) + w(3,8)*sin(y(8) - y(3)) + w(3,9)*sin(y(9) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4)) + w(4,5)*sin(y(5) - y(4)) + w(4,6)*sin(y(6) - y(4)) + w(4,7)*sin(y(7) - y(4)) + w(4,8)*sin(y(8) - y(4)) + w(4,9)*sin(y(9) - y(4));
            omega(5) + w(5,1)*sin(y(1) - y(5)) + w(5,2)*sin(y(2) - y(5)) + w(5,3)*sin(y(3) - y(5)) + w(5,4)*sin(y(4) - y(5)) + w(5,6)*sin(y(6) - y(5)) + w(5,7)*sin(y(7) - y(5)) + w(5,8)*sin(y(8) - y(5)) + w(5,9)*sin(y(9) - y(5));
            omega(6) + w(6,1)*sin(y(1) - y(6)) + w(6,2)*sin(y(2) - y(6)) + w(6,3)*sin(y(3) - y(6)) + w(6,4)*sin(y(4) - y(6)) + w(6,5)*sin(y(5) - y(6)) + w(6,7)*sin(y(7) - y(6)) + w(6,8)*sin(y(8) - y(6)) + w(6,9)*sin(y(9) - y(6));
            omega(7) + w(7,1)*sin(y(1) - y(7)) + w(7,2)*sin(y(2) - y(7)) + w(7,3)*sin(y(3) - y(7)) + w(7,4)*sin(y(4) - y(7)) + w(7,5)*sin(y(5) - y(7)) + w(7,6)*sin(y(6) - y(7)) + w(7,8)*sin(y(8) - y(7)) + w(7,9)*sin(y(9) - y(7));
            omega(8) + w(8,1)*sin(y(1) - y(8)) + w(8,2)*sin(y(2) - y(8)) + w(8,3)*sin(y(3) - y(8)) + w(8,4)*sin(y(4) - y(8)) + w(8,5)*sin(y(5) - y(8)) + w(8,6)*sin(y(6) - y(8)) + w(8,7)*sin(y(7) - y(8)) + w(8,9)*sin(y(9) - y(8));        
            omega(9) + w(9,1)*sin(y(1) - y(9)) + w(9,2)*sin(y(2) - y(9)) + w(9,3)*sin(y(3) - y(9)) + w(9,4)*sin(y(4) - y(9)) + w(9,5)*sin(y(5) - y(9)) + w(9,6)*sin(y(6) - y(9)) + w(9,7)*sin(y(7) - y(9)) + w(9,8)*sin(y(8) - y(9))                
            ];
elseif osci_no == 10
        dydt = [
            omega(1) + w(1,2)*sin(y(2) - y(1)) + w(1,3)*sin(y(3) - y(1)) + w(1,4)*sin(y(4) - y(1)) + w(1,5)*sin(y(5) - y(1)) + w(1,6)*sin(y(6) - y(1)) + w(1,7)*sin(y(7) - y(1)) + w(1,8)*sin(y(8) - y(1)) + w(1,9)*sin(y(9) - y(1)) + w(1,10)*sin(y(10) - y(1));
            omega(2) + w(2,1)*sin(y(1) - y(2)) + w(2,3)*sin(y(3) - y(2)) + w(2,4)*sin(y(4) - y(2)) + w(2,5)*sin(y(5) - y(2)) + w(2,6)*sin(y(6) - y(2)) + w(2,7)*sin(y(7) - y(2)) + w(2,8)*sin(y(8) - y(2)) + w(2,9)*sin(y(9) - y(2)) + w(2,10)*sin(y(10) - y(2));
            omega(3) + w(3,1)*sin(y(1) - y(3)) + w(3,2)*sin(y(2) - y(3)) + w(3,4)*sin(y(4) - y(3)) + w(3,5)*sin(y(5) - y(3)) + w(3,6)*sin(y(6) - y(3)) + w(3,7)*sin(y(7) - y(3)) + w(3,8)*sin(y(8) - y(3)) + w(3,9)*sin(y(9) - y(3)) + w(3,10)*sin(y(10) - y(3));
            omega(4) + w(4,1)*sin(y(1) - y(4)) + w(4,2)*sin(y(2) - y(4)) + w(4,3)*sin(y(3) - y(4)) + w(4,5)*sin(y(5) - y(4)) + w(4,6)*sin(y(6) - y(4)) + w(4,7)*sin(y(7) - y(4)) + w(4,8)*sin(y(8) - y(4)) + w(4,9)*sin(y(9) - y(4)) + w(4,10)*sin(y(10) - y(4));
            omega(5) + w(5,1)*sin(y(1) - y(5)) + w(5,2)*sin(y(2) - y(5)) + w(5,3)*sin(y(3) - y(5)) + w(5,4)*sin(y(4) - y(5)) + w(5,6)*sin(y(6) - y(5)) + w(5,7)*sin(y(7) - y(5)) + w(5,8)*sin(y(8) - y(5)) + w(5,9)*sin(y(9) - y(5)) + w(5,10)*sin(y(10) - y(5));
            omega(6) + w(6,1)*sin(y(1) - y(6)) + w(6,2)*sin(y(2) - y(6)) + w(6,3)*sin(y(3) - y(6)) + w(6,4)*sin(y(4) - y(6)) + w(6,5)*sin(y(5) - y(6)) + w(6,7)*sin(y(7) - y(6)) + w(6,8)*sin(y(8) - y(6)) + w(6,9)*sin(y(9) - y(6)) + w(6,10)*sin(y(10) - y(6));
            omega(7) + w(7,1)*sin(y(1) - y(7)) + w(7,2)*sin(y(2) - y(7)) + w(7,3)*sin(y(3) - y(7)) + w(7,4)*sin(y(4) - y(7)) + w(7,5)*sin(y(5) - y(7)) + w(7,6)*sin(y(6) - y(7)) + w(7,8)*sin(y(8) - y(7)) + w(7,9)*sin(y(9) - y(7)) + w(7,10)*sin(y(10) - y(7));
            omega(8) + w(8,1)*sin(y(1) - y(8)) + w(8,2)*sin(y(2) - y(8)) + w(8,3)*sin(y(3) - y(8)) + w(8,4)*sin(y(4) - y(8)) + w(8,5)*sin(y(5) - y(8)) + w(8,6)*sin(y(6) - y(8)) + w(8,7)*sin(y(7) - y(8)) + w(8,9)*sin(y(9) - y(8)) + w(8,10)*sin(y(10) - y(8));        
            omega(9) + w(9,1)*sin(y(1) - y(9)) + w(9,2)*sin(y(2) - y(9)) + w(9,3)*sin(y(3) - y(9)) + w(9,4)*sin(y(4) - y(9)) + w(9,5)*sin(y(5) - y(9)) + w(9,6)*sin(y(6) - y(9)) + w(9,7)*sin(y(7) - y(9)) + w(9,8)*sin(y(8) - y(9)) + w(9,10)*sin(y(10) - y(9));                
            omega(10)+w(10,1)*sin(y(1) -y(10)) + w(10,2)*sin(y(2)-y(10)) + w(10,3)*sin(y(3)-y(10)) + w(10,4)*sin(y(4)-y(10)) + w(10,5)*sin(y(5)-y(10)) + w(10,6)*sin(y(6)-y(10)) + w(10,7)*sin(y(7)-y(10)) + w(10,8)*sin(y(8)-y(10)) + w(10,9)*sin(y(9) - y(10))                
            ];
end
end

